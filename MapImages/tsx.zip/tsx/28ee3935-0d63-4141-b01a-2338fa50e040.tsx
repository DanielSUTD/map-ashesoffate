<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="28ee3935-0d63-4141-b01a-2338fa50e040" tilewidth="16" tileheight="16" tilecount="2" columns="1">
 <image source="../28ee3935-0d63-4141-b01a-2338fa50e040.png" width="20" height="40"/>
</tileset>
