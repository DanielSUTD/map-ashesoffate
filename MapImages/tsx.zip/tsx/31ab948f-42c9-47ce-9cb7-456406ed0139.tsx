<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="31ab948f-42c9-47ce-9cb7-456406ed0139" tilewidth="16" tileheight="16" tilecount="2" columns="1">
 <image source="../31ab948f-42c9-47ce-9cb7-456406ed0139.png" width="27" height="37"/>
</tileset>
