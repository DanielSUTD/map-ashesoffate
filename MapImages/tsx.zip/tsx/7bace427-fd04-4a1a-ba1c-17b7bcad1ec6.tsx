<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="7bace427-fd04-4a1a-ba1c-17b7bcad1ec6" tilewidth="16" tileheight="16" tilecount="6" columns="3">
 <image source="../7bace427-fd04-4a1a-ba1c-17b7bcad1ec6.png" width="48" height="37"/>
</tileset>
