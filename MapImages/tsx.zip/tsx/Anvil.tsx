<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Anvil" tilewidth="16" tileheight="16" tilecount="170" columns="17">
 <image source="../Anvil.png" width="272" height="160"/>
</tileset>
