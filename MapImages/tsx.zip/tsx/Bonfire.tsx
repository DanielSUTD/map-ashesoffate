<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Bonfire" tilewidth="16" tileheight="16" tilecount="96" columns="4">
 <image source="../Bonfire.png" width="64" height="384"/>
</tileset>
