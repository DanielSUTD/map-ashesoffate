<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Bridge_All" tilewidth="16" tileheight="16" tilecount="192" columns="12">
 <image source="../Bridge_All.png" width="192" height="256"/>
</tileset>
