<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Castle_Construction" tilewidth="16" tileheight="16" tilecount="320" columns="20">
 <image source="../Castle_Construction.png" width="320" height="256"/>
</tileset>
