<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Fall Tile" tilewidth="16" tileheight="16" tilecount="210" columns="15">
 <image source="../Fall Tile.png" width="240" height="224"/>
</tileset>
