<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Fence's copiar" tilewidth="16" tileheight="16" tilecount="15" columns="3">
 <image source="../Fence's copiar.png" width="48" height="80"/>
</tileset>
