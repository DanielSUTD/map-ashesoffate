<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Floors" tilewidth="16" tileheight="16" tilecount="625" columns="25">
 <image source="../Floors.png" width="400" height="400"/>
</tileset>
