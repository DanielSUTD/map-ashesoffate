<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Furniture" tilewidth="16" tileheight="16" tilecount="2700" columns="50">
 <image source="../Furniture.png" width="800" height="864"/>
</tileset>
