<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Interior" tilewidth="16" tileheight="16" tilecount="108" columns="12">
 <image source="../Interior.png" width="192" height="144"/>
</tileset>
