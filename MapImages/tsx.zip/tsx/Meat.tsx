<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Meat" tilewidth="16" tileheight="16" tilecount="36" columns="4">
 <image source="../Meat.png" width="64" height="144"/>
</tileset>
