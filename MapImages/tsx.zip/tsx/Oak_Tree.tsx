<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Oak_Tree" tilewidth="16" tileheight="16" tilecount="20" columns="4">
 <image source="../Oak_Tree.png" width="64" height="80"/>
</tileset>
