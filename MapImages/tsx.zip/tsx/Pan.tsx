<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Pan" tilewidth="16" tileheight="16" tilecount="110" columns="10">
 <image source="../Pan.png" width="160" height="176"/>
</tileset>
