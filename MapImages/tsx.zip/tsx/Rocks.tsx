<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Rocks" tilewidth="16" tileheight="16" tilecount="247" columns="13">
 <image source="../Rocks.png" width="208" height="304"/>
</tileset>
