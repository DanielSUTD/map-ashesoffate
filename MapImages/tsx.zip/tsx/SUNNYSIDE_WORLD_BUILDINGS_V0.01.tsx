<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="SUNNYSIDE_WORLD_BUILDINGS_V0.01" tilewidth="16" tileheight="16" tilecount="1600" columns="40">
 <image source="../SUNNYSIDE_WORLD_BUILDINGS_V0.01.png" width="640" height="640"/>
</tileset>
