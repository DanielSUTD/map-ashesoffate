<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Set 1.0" tilewidth="16" tileheight="16" tilecount="252" columns="18">
 <image source="../Set 1.0.png" width="288" height="224"/>
</tileset>
