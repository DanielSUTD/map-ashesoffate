<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Size_03" tilewidth="16" tileheight="16" tilecount="90" columns="9">
 <image source="../Size_03.png" width="144" height="160"/>
</tileset>
