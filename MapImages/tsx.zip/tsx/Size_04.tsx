<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Size_04" tilewidth="16" tileheight="16" tilecount="168" columns="12">
 <image source="../Size_04.png" width="192" height="224"/>
</tileset>
