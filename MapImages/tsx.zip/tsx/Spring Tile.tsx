<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Spring Tile" tilewidth="16" tileheight="16" tilecount="210" columns="15">
 <image source="../Spring Tile.png" width="240" height="224"/>
</tileset>
