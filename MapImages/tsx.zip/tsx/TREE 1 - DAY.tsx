<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="TREE 1 - DAY" tilewidth="16" tileheight="16" tilecount="9" columns="3">
 <image source="../TREE 1 - DAY.png" width="48" height="48"/>
</tileset>
