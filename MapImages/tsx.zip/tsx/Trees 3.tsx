<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Trees 3" tilewidth="16" tileheight="16" tilecount="50" columns="10">
 <image source="../Trees 3.png" width="160" height="80"/>
</tileset>
