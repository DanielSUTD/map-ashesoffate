<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Wood_Tower_Yellow" tilewidth="16" tileheight="16" tilecount="768" columns="64">
 <image source="../Wood_Tower_Yellow.png" width="1024" height="192"/>
</tileset>
