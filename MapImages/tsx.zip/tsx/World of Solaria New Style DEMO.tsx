<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="World of Solaria New Style DEMO" tilewidth="16" tileheight="16" tilecount="120" columns="10">
 <image source="../World of Solaria New Style DEMO.png" width="160" height="192"/>
</tileset>
