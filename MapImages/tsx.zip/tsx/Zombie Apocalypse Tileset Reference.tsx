<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Zombie Apocalypse Tileset Reference" tilewidth="16" tileheight="16" tilecount="846" columns="47">
 <image source="../Zombie Apocalypse Tileset Reference.png" width="764" height="300"/>
</tileset>
