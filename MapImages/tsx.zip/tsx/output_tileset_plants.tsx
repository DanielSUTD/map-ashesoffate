<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="output_tileset_plants" tilewidth="16" tileheight="16" tilecount="899" columns="29">
 <image source="../output_tileset_plants.png" width="468" height="504"/>
</tileset>
